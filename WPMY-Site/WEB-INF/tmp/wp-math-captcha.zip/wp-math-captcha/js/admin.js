jQuery(document).ready(function($) {

	$('.wplikebtns').buttonset();
});